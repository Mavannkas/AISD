package ludwiniak.wiktor.Lab.L2;

public class Inserter {
    public static TwoWayLinkedList<String> insert(
            TwoWayLinkedList<String> list1,
            TwoWayLinkedList<String> list2,
            int beforeIndex) {
        // TODO
        return null;
    }

    public static TwoWayLinkedList<String> insert(
            TwoWayLinkedList<String> list1,
            TwoWayLinkedList<String> list2,
            String beforeElement) {
        // TODO
        return null;

    }
}
