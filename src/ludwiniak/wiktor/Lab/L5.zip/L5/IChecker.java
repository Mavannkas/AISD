package ludwiniak.wiktor.Lab.L5;


public interface IChecker {
    void check(int[] array);
}
