package ludwiniak.wiktor.Lab.L5;


public interface ISorter {
    void sort(int[] values);
}
